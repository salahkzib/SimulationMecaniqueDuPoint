var stage,canv
	var cjs=createjs
	var expM1='\u207B\u00B9',ind0='\u2080',indm='\u2098',pi='\u03c0',om='\u03C9',thet='\u03B8',lamb='\u03BB'
	var pi='\u03c0',phi='\u03C6',omega='\u03C9',theta='\u03B8',lambda='\u03BB',Tau='\u03C4'
	var x0,v0,m,k,h,Ec,Ep,E0,ech,lambda,tau,omega,omega0,tpas=0.05,per0,B,t,tg,tchrono,joue=true,expo,arg;
	var echx=10



/////////
	
	function init(){
	canv = document.getElementById("testCanvas");
	canv.style.backgroundColor='#EFF'
	canv.parentNode.style.backgroundColor=canv.style.backgroundColor;
	//dimensions du canvas
	canv.width=860,canv.height=600;
	//Bouton plein écran
	var btPE=new BoutonPleinEcran(canv,'#009').set({x:50,y:550})

	stage = new createjs.Stage(canv);
	stage.enableMouseOver();
	cjs.Touch.enable(stage)
	cjs.Ticker.framerate=25
	//createjs.Ticker.timingMode = createjs.Ticker.RAF_SYNCHED;
	cjs.Ticker.on("tick", tick);
	function tick(evt) { calcule() }
	
	var txtEmploi="Le système masse-ressort,  pseudo-isolé, constitue un oscillateur harmonique horizontal.\nL'animation permet de paramétrer, avec des curseurs :\n- l'abscisse initiale xo\n- la vitesse initiale Vo\n- la masse m\n- la constante de raideur du ressort k (force de rappel du ressort : F = -k.x i )\n- le coefficient d'amortissement h (force de frottement : f = -h.V)\nUn chronomètre permet de mesurer la période (1 clic pour démarrer, un clic pour arrêter, et un 3ème clic pour remettre à zéro).\nLe bouton Reset permet de réinitialiser, le bouton Pause permet de figer l'animation.\nDes boutons permettent d'afficher les vecteurs vitesse, accélération et forces (forces H pour les forces dirigées horizontalement, et forces V pour les forces dirigées verticalement ; l'échelle est différente). Pour plus de lisibilité, leurs points d'application sont ramenés au centre d'inertie de la masse.\nUn graphe permet de visualiser les valeurs algébriques de l'abscisse et de la vitesse.\nUn autre permet de visualiser la répartition de l'énergie, en proportion de l'énergie initiale Eo.\nUn bargraph montre les valeurs de ces énergies."
				
	var aide=new Aide(60,60,txtEmploi,450);
	aide.x=30;
	aide.y=30;
	
	var systeme=new cjs.Container().set({x:420,y:250})
	
	
	//boutons
	var contBt=new cjs.Container().set({x:-300,y:-180})
	var bt1=new Bouton('vitesse',"#909",80).set({x:0,y:0})
	bt1.on('click',function(){Vvit.visible=!Vvit.visible})
	var bt2=new Bouton('accélération',"#909",80).set({x:0,y:30})
	bt2.on('click',function(){Vma.visible=!Vma.visible})
	var bt3=new Bouton('forces H',"#909",80).set({x:0,y:60})
	bt3.on('click',function(){Vtension.visible=!Vtension.visible;Vfrot.visible=Vtension.visible})
	var bt4=new Bouton('forces V',"#909",80).set({x:0,y:90})
	bt4.on('click',function(){Vpoids.visible=!Vpoids.visible;Vreac.visible=Vpoids.visible})
	contBt.addChild(bt1,bt2,bt3,bt4)
	
	//autres boutons
	var contBt1=new cjs.Container().set({x:-140,y:-50})
	var bt1=new BoutonRond('Reset','#FC0',"#F60",50).set({x:0,y:0})
	bt1.on('click',function(){raz()})
	var bt2=new BoutonRond('Stop','#FC0',"#F60",50).set({x:80,y:0})
	bt2.on('click',function(){joue=!joue})
	contBt1.addChild(bt1,bt2)
	

	
	//curseurs
	var contCur=new cjs.Container().set({x:-300,y:-50})
	var curx=new Curseur(-50,50,100,30,'#909').set({y:0})
	curx.on('pressmove',function(){curx.txt.text='x'+ind0+' = '+(0.1*curx.value).toFixed(2)+' cm'})
	curx.txt.text='x'+ind0+' = '+(0.1*curx.value).toFixed(2)+' cm'
	var curv=new Curseur(-5,5,100,0,'#F63').set({y:30})
	curv.txt.text='v'+ind0+' = '+curv.value.toFixed(2)+' cm.s'+expM1
	curv.on('pressmove',function(){curv.txt.text='v'+ind0+' = '+curv.value.toFixed(2)+' cm.s'+expM1})
	var curm=new Curseur(0.5,1.5,100,1,'#F09').set({y:60})
	curm.txt.text='masse : m = '+curm.value.toFixed(3)+' kg'
	curm.on('pressmove',function(){curm.txt.text='masse : m = '+curm.value.toFixed(3)+' kg'})
	var curk=new Curseur(0.5,1.5,100,1,'#090').set({y:90})
	curk.txt.text='constante de raideur : k = '+curk.value.toFixed(3)+' N.m'+expM1
	curk.on('pressmove',function(){curk.txt.text='constante de raideur : k = '+curk.value.toFixed(3)+' N.m'+expM1})
	var curh=new Curseur(0,2,100,0,'#17A').set({y:120})
	curh.txt.text='coefficient de frottement : h = '+curh.value.toFixed(3)+' kg.s'+expM1
	curh.on('pressmove',function(){curh.txt.text='coefficient de frottement : h = '+curh.value.toFixed(3)+' kg.s'+expM1})
	contCur.addChild(curx,curv,curm,curk,curh)

	//banc
	var pendule=new cjs.Container().set({x:-170,y:-150})
	var banc=new cjs.Shape()
	banc.graphics.f('#AAA').dr(0,0,460,24).ef().ss(4,1).s('#333').mt(0,25).lt(0,-40).ss(2).mt(0,-20).lt(22,-20)
	var txtress='iVBORw0KGgoAAAANSUhEUgAAAHkAAAAUCAYAAACpkJLNAAAE9klEQVRoge2ZwZXbNhCG/4F8tzowO7A6sDowXUGYpyV1tFyB6Qqi60LWe3IHSgd0B3IHdAfaAhZ/DhzkURRAUrJ24yT+TxQ0wDfkgANwIIioKIrfSM4BJIG/axGpAOyttQ8AsFwuX5PMSM5C44lIJSL7+/v7bzr+SwApgJTk9LkYIpLo9UFEjiQr59x+u91+B4DFYvHKGJNqv5BqkvvPnz//6Rvu7u7eikgaeVYAsH9Khr8PEdn5Z3Xyf7chz/P3AEoANYAdgEPAiRmATESmAPYk563rfdeY5FQdTEWkInn019qnfi6Gc66eTCZHkjMN+FztdgD87z3JvYgc+/zSBztXVvBZdf3StpsyAMxEZI5m0qwBlO1gnwS5KIqPJFOSZXsWxZTn+XsRWYcGDkln8B5AYoyZ+zduDIPkTkRWlzAApJvN5usQQ/scROQoIukYv4qi+APACkBmrf0yZK9ZaE+yds5l/q1+AkYJoLbWfvDtxl/kef6e5Mo5l44JcFEUL0VkBWBNchZLoW0ZY1IRmWrQygsYezQpdzQDTbpfDdkDwGQyWQM4kDyO8SvP8zdo3pqS5EqXhV6RLDWb1Jqqb864v7//Zq19R3KqGRmABnm5XL4GUBpj5mNmmGpHsrLWfnDOZSKy63PEM0QktdZ+AlAXRfFxJOOdiKwuYWiKS9o3G5JO7mRsH514OzSZ65MG72z5iDE2m83vADIN4s0YbXUZBgCcc2sRWY9JU+r0GwAzHQw6MXZoUktQyli1GCWALBa0LsNa+0XfhFEMTesrAGWMoe2lcy611j6M6QNgpRPvCwD4rBcLWpfhx9D7j+kiRmwMzzCLxeIVmoV+fcEAGckT+8fHxx2ALGTsGe11xVr7QLJCfId5xlCnRzN0PT70MFIRqdrZa0SfzBhz4pe+dUG/YgwRSdTnWzDO1GaYyWQyF5FqaEPTAc6NMVW7rf150LX3jMA4le40RzE2m81XktNLGNCdeYhBcq4TbVSfxWLxiuS0m/EeHx8r3d2OZpCsJpPJTRgxeYZBswsNbcv7lIRSO8naGJOE7EMMTb8h+ygDwOEShrZFGZf0Ue6ZvU7wixgiUt+QEZRnvIjM5F/6D8jH9sWY78hf+nfKx/bFP+3Izyhd+y5dwn5amWGToGr9Ju1q5pyrQ/ZodvBn9vrfkzFEJImM3+cXAJyVG5V7Zt+zS44ySAb9upLRq6uCrKW5s0MFEZmGiikk69AhhFa/6qdkAEgiu26ISK3Vsa5mWis+0Xa7/R6yN8Yksb1NDyPY5xrGkK4Ksogcutv5PM/fkAymuJA90HxeOOdG97mSkURuA865Q+TzaoZIuiZ56BYl+rJFjNHX51LGkK5N1weSJ8UCPWkJPhj9Bq/v7u7e+jYt3c1jQbsFQzWLvQEkDyIyb1e39Drp2ZAe1I8TRixbPAdjSNcGeQ8gaa+ZJDM0pc2YdsaYrG1Psuqplf8wQ/smIhKcGNvt9jvJSsc98auPASD1QfNn1rE+z8EY0lVBttY+iMjKn9hoQf/Q9zmmZc90uVy+bp0ulX0MNJWn0Qw9+Jj5iUGyHDqe1MOVVVEUL71fzrksZq9Vt7+D5gPW59dzMPp07ZvsDwyORVEQzQlW77GevrGZpufjGKd1IiVjGdondc5VRVGQ5HHoHFb9KtHspo8AyqGTOJ2gmfqVDR1pPgfjl/7n+gsTtHnb82JzZQAAAABJRU5ErkJggg=='
	var wr=200
	var ressort=new Ressort(wr,25,10,'#333').set({x:20,y:-20})
	var contMasse=new cjs.Container().set({x:180,y:-50})
	var masse=new cjs.Shape()
	masse.graphics.lf(["#90C","#EAF","#90C"], [0,0.8,1], -20, 0, 20, 0).dr(-20,10,40,39)
	masse.graphics.ss(3).s("#555").mt(0,-10).lt(0,10).mt(-20,30).lt(-40,30)
	contMasse.addChild(masse)
	var maxx=470,co='#929'
	var axe=new cjs.Shape(new cjs.Graphics().ss(1).s(co).mt(-20,0).lt(maxx,0).mt(180,-8).lt(180,8).f(co).lt(maxx-10,-5).qt(maxx,0,maxx-10,5).lt(maxx,0).lt(maxx-10,-5))
	axe.graphics.ss(2).s(co).mt(180,0).lt(210,0).mt(203,-4).lt(210,0).lt(203,4)
	axe.y=35;
	var ta=new cjs.Text('0','bold 16px Arial Narrow',co).set({x:177,y:42})
	var ta1=new cjs.Text('x','bold 16px Arial Narrow',co).set({x:470,y:42})
	var vini=texteFleche(' i ','12px Arial',co).set({x:210,y:50})
	var regle=new cjs.Container().set({x:180,y:-50})
	var fondregle=new cjs.Shape()
	fondregle.graphics.f('#CCC').dr(-150,-30,300,30)
	var contGrad=new cjs.Container()
	var grad=new cjs.Shape()
	contGrad.addChild(grad)
	grad.graphics.s(1).s('black')
	var pasregle=10
	for(var k=-10;k<11;k++){
		grad.graphics.mt(k*pasregle,0).lt(k*pasregle,-10)
		if(k%5==0){
		contGrad.addChild(new cjs.Text(k,'14px Arial Narrow','black').set({x:k*pasregle,y:-25,textAlign:'center'}))
		}
	}
	var inter=new cjs.Shape()
	inter.graphics.f('#EEE').dr(-100,-30,200,30)
	regle.addChild(fondregle,inter,contGrad)
	pendule.addChild(banc,ressort,regle,contMasse,axe,vini,ta,ta1)
	
	//chronomètre
	var chrono=new Chrono().set({x:320,y:-170})
	var txch=new cjs.Text('chronomètre','14px Arial Narrow','black').set({x:10,y:-20})
	chrono.addChild(txch)
	//affichage
	var aff=new cjs.Container().set({x:-180,y:120})
	var fond=new cjs.Shape()
	fond.graphics.ss(1).s('#D80').f('#FFA').rr(-140,-10,280,210,8)
	var txt1=new cjs.Text('l\'équation :\n\n\nLa solution :','13px Arial','red').set({x:0,y:0,textAlign:'center'})
	var txt2=new cjs.Text('x" + (h/m)x\' + (k/m)x = 0','bold 18px Arial','#009').set({x:0,y:18,textAlign:'center'})
	var txt3=new cjs.Text('x =','bold 18px Arial','#009').set({x:0,y:55,textAlign:'center'})
	var txtreg=new cjs.Text('régime','bold 14px Arial','red').set({x:0,y:80,textAlign:'center'})
	var txtamp=new cjs.Text('A =','14px Arial','#009').set({x:-80,y:100,textAlign:'left'})
	var txtper=new cjs.Text('B =','14px Arial','#009').set({x:-80,y:120,textAlign:'left'})
	var txtphi=new cjs.Text('A =','14px Arial','#009').set({x:-80,y:140,textAlign:'left'})
	var txtpseudo=new cjs.Text('pseudo =','14px Arial','#009').set({x:-80,y:160,textAlign:'left'})
	var txt4=new cjs.Text('pseudo =','14px Arial','#009').set({x:-80,y:180,textAlign:'left'})
	
	
	aff.addChild(fond,txt1,txt2,txt3,txtreg,txtamp,txtper,txtpseudo,txt4)
	
	//graphes
	var contGraph=new cjs.Container().set({y:30})
	var graph1=new cjs.Container()
	var axes1=dessineAxes(-20,340,100,-120,'t(s)','x(cm)','black','green','#D0D')
	axes1.getChildByName('txy').setTransform(30,-120)
	var grad1=new cjs.Shape()
	grad1.graphics.s('black').mt(200,10).lt(200,-10).mt(-10,-100).lt(10,-100)
	var t1=new cjs.Text('10','bold 14px Arial Narrow','black').set({x:-28,y:-108})
	var t2=new cjs.Text('10','bold 14px Arial Narrow','black').set({x:193,y:12})
	axes1.addChild(grad1,t1,t2)
	var txv=new cjs.Text('v(cm/s)','bold 16px Arial Narrow','#F60').set({x:50,y:-120})
	var grille1=dessineGrille(0,16,20,-10,10,10,0x999999,0.7)
	var elon=new cjs.Shape();
	var vit=new cjs.Shape()
	var tang=new cjs.Shape()
	tang.graphics.s('red').mt(-15,-5).lt(-20,0).lt(-15,5).mt(-20,0).lt(20,0).mt(15,-5).lt(20,0).lt(15,5).mt(0,0).f('red').dc(0,0,3)
	var commentaire=new cjs.Container().set({x:120,y:-100})
	var fondcom=new cjs.Shape()
	fondcom.graphics.s('red').f('#FEE').rr(0,0,180,40,4)
	var txcom=new cjs.Text('le coefficient directeur de la tangente à la courbe x(t) est égal à  la vitesse algébrique dx/dt','10px Arial','red').set({x:90,y:5,textAlign:'center',lineWidth:160})
	commentaire.addChild(fondcom,txcom)
	commentaire.cursor='pointer'
	dragAndDrop(commentaire)
	graph1.addChild(grille1,axes1,elon,vit,tang,txv,commentaire)
	
	var graph2=new cjs.Container().set({y:280})
	var axes2=dessineAxes(-20,340,20,-140,'t(s)','   énergies(%E'+ind0+')','black','green','#666')
	var grad2=new cjs.Shape()
	grad2.graphics.s('black').mt(200,10).lt(200,-10).mt(-10,-120).lt(10,-120)
	var t3=new cjs.Text('100','bold 14px Arial Narrow','black').set({x:-28,y:-128})
	var t4=new cjs.Text('10','bold 14px Arial Narrow','black').set({x:193,y:12})
	axes2.addChild(grad2,t3,t4)
	var txEc=new cjs.Text('Ec','bold 14px Arial','#F00').set({x:70,y:-140})
	var txEp=new cjs.Text('Ep','bold 14px Arial','#0D0').set({x:95,y:-140})
	var txEm=new cjs.Text('Em','bold 14px Arial','#009').set({x:80,y:-155})
	var grille2=dessineGrille(0,16,20,0,12,-10,0x999999,0.7)
	var Encin=new cjs.Shape()
	var Enpot=new cjs.Shape()
	var Enm=new cjs.Shape()
	graph2.addChild(grille2,axes2,Encin,Enpot,Enm,txEc,txEm,txEp)
	
	contGraph.addChild(graph1,graph2)
	
	//énergie
	var bargraph=new cjs.Container().set({x:390,y:310})
	var Epot=new cjs.Shape()
	Epot.graphics.f('#0A0').dr(-10,0,20,-100)
	var Ecin=new cjs.Shape()
	Ecin.graphics.f('#F00').dr(-10,0,20,-100)
	var trait=new cjs.Shape(new cjs.Graphics().s('black').mt(-20,0).lt(20,0))
	var zero=new cjs.Text('0','14px Arial','black').set({x:-35,y:-5})
	var Emtx=new cjs.Text('Em','bold 14px Arial','#00A').set({x:-10,y:-40})
	var Eptx=new cjs.Text('Ep','bold 14px Arial','#0A0').set({x:20,y:-10})
	var Ectx=new cjs.Text('Ec','bold 14px Arial','#F00').set({x:20,y:10})
	bargraph.addChild(Epot,Ecin,trait,zero,Emtx,Eptx,Ectx)
	
	
	//vecteurs
	var contVecteurs=new cjs.Container().set({y:30})
	var Vtension=new Vecteur0('F', '#0D0',new cjs.Point()).set({visible:false})
	var Vfrot=new Vecteur0('f', '#0CF',new cjs.Point()).set({visible:false})
	var Vpoids=new Vecteur0('P', '#F09',new cjs.Point(0,50)).set({visible:false})
	var Vreac=new Vecteur0('R', '#36F',new cjs.Point(0,-50)).set({visible:false})
	var Vma=new Vecteur0('a', '#33F',new cjs.Point()).set({visible:false})
	var Vvit=new Vecteur0('V', '#F00',new cjs.Point()).set({visible:false})
	contVecteurs.addChild(Vtension,Vfrot,Vpoids,Vreac,Vma,Vvit)
	contMasse.addChild(contVecteurs)

	//signature
	var signature=signer('11/2025','#009').set({x:50,y:480})
	
	systeme.addChild(pendule,contCur,contBt,contBt1,aff,contGraph,bargraph,chrono)
	
	
	stage.addChild(systeme,signature,aide,btPE)
	
	raz()
		
		
	function calcule(){
		if (joue) {
		t += tpas;
		tg += 0.1;
		ts = Math.floor(tchrono);
		tc = Math.round(100*(tchrono-ts));
		if (tg>32) {
			tg = 0;
			with (elon.graphics) {
				clear();
				ss(2).s('#90C').moveTo(0, -x);
			}
			with (vit.graphics) {
				clear();
				ss(2).s('#F63').mt(0, -v);
			}
			with (Encin.graphics) {
				clear();
				ss(2).s('#F00').mt(0, -Ec/ech);
			}
			with (Enpot.graphics) {
				clear();
				ss(2).s('#0D0').mt(0, -Ep/ech);
			}
			with (Enm.graphics) {
				clear();
				ss(2).s('#00D').mt(0, -Em/ech);
			}
		}
		expo = Math.exp(-lambda*t);
		arg = omega*t;
		if (omega0>lambda) {
			//régime pseudo-périodique ou périodique
			x = expo*(x0*Math.cos(arg)+B*Math.sin(arg));
			v = expo*((-lambda*x0+omega*B)*Math.cos(arg)-(lambda*B+omega*x0)*Math.sin(arg));
		} else if (omega0<lambda) {
			//régime surcritique
			x = expo*(x0*ch(arg)+B*sh(arg));
			v = expo*((-lambda*x0+omega*B)*ch(arg)+(-lambda*B+omega*x0)*sh(arg));
		} else {
			//régime critique
			x = expo*(x0+B*t);
			v = expo*(v0-lambda*B*t);
		}
		if (Math.abs(x)>xm) {
			xm = Math.abs(x);
		}
		inter.scaleX = xm/100;
//		pendule._Elong = x;
		masse.x=x
		contVecteurs.x=x
		//ressort.scaleX=(contMasse.x+x-58)/wr
		ressort.lon=(contMasse.x+x-58)
		Fe = -k*x;
		Ff = -h*v;
		Ac = (Fe+Ff)/m;
		Vtension.V=new cjs.Point(Fe*3,0)
		Vfrot.V=new cjs.Point(Ff*3,0)
		Vvit.V=new cjs.Point(v*3,0)
		Vma.V=new cjs.Point((Fe+Ff)*2,0)
		
		//Vtension.x=masse.x
		Ep = 0.5*k*x*x;
		Ec = 0.5*m*v*v;
		Em = Ec+Ep;
		tang.x = tg*10;
		tang.y = -x;
		tang.rotation = -180/Math.PI*Math.atan(v/20);
		elon.graphics.lineTo(tg*10, -x);
		vit.graphics.lineTo(tg*10, -v);
		Encin.graphics.lineTo(tg*10, -Ec/ech);
		Enpot.graphics.lineTo(tg*10, -Ep/ech);
		Enm.graphics.lineTo(tg*10, -Em/ech);
		Ecin.scaleY = Ec/1000;
		Epot.scaleY = Ep/1000;
		Epot.y = -Ec/10;
		Ectx.y = -10-Ec/20;
		Eptx.y = -10-Ec/10-Ep/20;
		Emtx.y = -20-Em/10;
	}
		
		
		
		stage.update()
	
	}
	function initGraph(){

	}
	function raz(){
		//joue = true;
		txt2.text=''
		txt3.text=''
		txtreg.text=''
		txtamp.text=''
		txtper.text=''
		txtphi.text=''
		txtpseudo.text=''
		txt4.text=''
		x0=curx.value;
		v0=10*curv.value;
		m=curm.value;
		k=curk.value;
		h=curh.value;
		tchrono = 0;
		xm=0
		Ec = 0.5*m*v0*v0;
		Ep = 0.5*k*x0*x0;
		E0 = Ec+Ep;
		ech = E0/120;
		lambda = h/2/m;
		tau = 1/lambda;
		omega0 = Math.sqrt(k/m);
		per0 = 2*Math.PI/omega0;
		if (lambda == omega0) {
			//régime critique : x=amp*exp(-t/tau)(1+t/T1)
			amp = x0;
			B = v0+lambda*x0;
		} else if (lambda<omega0) {
			//régime pseudo-périodique
			omega = Math.sqrt(omega0*omega0-lambda*lambda);
			per = 2*Math.PI/omega;
			B = (v0+lambda*x0)/omega;
			phi0 = -Math.atan(B/x0);
			amp = Math.sqrt(x0*x0+B*B);
		} else {
			//régime apériodique
			omega = Math.sqrt(lambda*lambda-omega0*omega0);
			B = (v0+lambda*x0)/omega;
		}
	t = 0;
	tg = 0;
	tchrono = 0;
	//chrono.n = 0;
//	pendule.regle.inter._xscale=xm
		elon.graphics.clear().ss(2).s('#90C').mt(0, -x0);
		vit.graphics.clear().ss(2).s('#F63').mt(0, -v0);
		Encin.graphics.clear().ss(2).s('#F00').mt(0, -Ec/ech)
		Enpot.graphics.clear().ss(2).s('#0D0').mt(0, -Ep/ech);
		Enm.graphics.clear().ss(2).s('#00D').mt(0, -E0/ech);
//	}
//	with (aff) {
		if (h == 0) {
//			gotoAndStop(1);
			txt2.text='x" + (k/m)x = 0'
			txt3.text= 'x = X'+indm+'cos(2'+pi+'t/T'+ind0+'+'+phi+ind0+')' 
			txtreg.text = "régime périodique";
			txtper.text = "période : To = "+per0.toFixed(2)+" s";
			txtamp.text = "amplitude : Xm = "+amp.toFixed(2)+" cm";
			txtphi.text = "phase à l'origine : "+phi+ind0+phi0.toFixed(2)+" rad";
			txt4.text = "phase à l'origine : "+phi+ind0+" = "+phi0.toFixed(2)+" rad";
		} else {
			txt2.text='x" + (h/m)x\' + (k/m)x = 0'
			txtamp.text = "A = "+amp.toFixed(2)+" cm";
			if (omega0>lambda) {
//				gotoAndStop(2);
				txt3.text='x = A exp(-t/'+Tau+') cos(2'+pi+'t/T+'+phi+ind0+')' 
				txtreg.text = "régime pseudo-périodique";
				txtphi.text = "période propre : T"+ind0+" = "+per0.toFixed(2)+" s";
				txtpseudo.text = "constante de temps : "+Tau+' = '+tau.toFixed(2)+" s";
				txtper.text = "pseudo-période : T = "+per.toFixed(2)+" s";
				txt4.text = "phase à l'origine : "+phi+ind0+" = "+phi0.toFixed(2)+" rad";
			}
			 else if (omega0<lambda) {
				//gotoAndStop(4);
				txt3.text='x = exp(-t/'+Tau+') [A ch(t/T)+B sh(t/T)] '
				txtphi.text = "paramètre : T = "+per.toFixed(2)+" s";
				txtreg.text = "régime apériodique";
				txtper.text = "B = "+B.toFixed(2)+" cm";
				txtpseudo.text = "constante de temps : "+Tau+" = "+tau.toFixed(2)+" s";
				txt4.text = "";
			} else {
//				gotoAndStop(3);
				txt3.text='x = exp(-t/'+Tau+') [A+B.t]   '
				txtper.text = "B = "+(0.1*B).toFixed(2)+" cm.s"+expM1;
				txtreg.text = "régime apériodique critique";
				txtpseudo.text = "";
				txtphi.text = "constante de temps : "+Tau+" = "+tau.toFixed(2)+" s";
				txt4.text = "";
			}
		}
//	}
//}


		stage.update()

	}
}
/////////////fonctions
function texteFleche(txt,font,co){
		var f=6
		var cont=new createjs.Container()
		var texte=new createjs.Text(txt,font,co).set({textAlign:'center'})
		var bds=texte.getBounds()
		var lon=bds.width
		var deb=bds.x
		var fl=new createjs.Shape().set({y:-5})
		//this.fl=fl
		fl.graphics.ss(2,"round").s(co).mt(deb,0).lt(deb+lon,0).lt(deb+lon+f*Math.cos(2.6), f*Math.sin(2.6)).mt(deb+lon, 0).lt(deb+lon+f*Math.cos(2.6), -f*Math.sin(2.6))
		cont.addChild(texte,fl)
		return cont
}
function dragAndDrop(obj){
		var pos0
		obj.on('mousedown',function(evt){pos0=new cjs.Point(evt.localX,evt.localY)})
		obj.on("pressmove", function(evt){
			var pos=(obj.parent.globalToLocal(evt.stageX-pos0.x,evt.stageY-pos0.y))
			obj.x=pos.x;obj.y=pos.y
			stage.update()
		});
	}

function ch(x) {
	return 0.5*(Math.exp(x)+Math.exp(-x));
}
function sh(x) {
	return 0.5*(Math.exp(x)-Math.exp(-x));
}

function dessineGrille(minx,maxx,pasx,miny,maxy,pasy,col,trans){
	var contGrille=new cjs.Container()	
	var grille=new createjs.Shape()
	with(grille){
		alpha=1;
		//graphics.beginStroke('#666');
		for (var j = miny; j<=maxy; j++) {
			graphics.ss(1).s(cjs.Graphics.getRGB(col,trans));
			graphics.moveTo(pasx*minx, j*pasy);
			graphics.lineTo(pasx*maxx,j*pasy);
		}
		for (var l = minx; l<=maxx; l++) {
			graphics.ss(1).s(cjs.Graphics.getRGB(col,trans));
			graphics.moveTo(l*pasx, pasy*miny);
			graphics.lineTo(l*pasx,pasy*maxy);
		}
	}
	contGrille.addChild(grille)
	return contGrille
}
function dessineAxes(minx,maxx,miny,maxy,tx,ty,co,cox,coy){
	var axes=new cjs.Container()
	var ax=new cjs.Shape(new cjs.Graphics().ss(1).s(co).mt(minx,0).lt(maxx,0).f(co).lt(maxx-10,-5).qt(maxx,0,maxx-10,5).lt(maxx,0).lt(maxx-10,-5).ef().mt(0,miny).lt(0,maxy).f(co).lt(-5,maxy+10).qt(0,maxy,5,maxy+10).lt(0,maxy).lt(-5,maxy+10).ef())
	ax.name='ax'
	var or=new cjs.Text('0','bold 14px Arial',co).set({x:-15,y:10})
	var txx=new cjs.Text(tx,'bold 16px Arial Narrow',cox).set({x:maxx-10,y:10,textAlign:'center'})
	txx.name='txx'
	var txy=new cjs.Text(ty,'bold 16px Arial Narrow',coy).set({x:0,y:maxy-15,textAlign:'center'})
	txy.name='txy'
	axes.addChild(ax,or,txx,txy)
	return axes
}
function dessineImagePng(txt){
	return new createjs.Bitmap('data:image/png;base64,'+txt)
}

cjs.DisplayObject.prototype.pos = function(P) {
	this.x = P.x;
	this.y = P.y;
};

function loc(ob){return new cjs.Point(ob.x,ob.y)}
cjs.DisplayObject.prototype.tourne=function(){
	var pos0
	this.on('mousedown',function(evt){pos0=new cjs.Point(evt.localX,evt.localY),beta0=beta,alpha0=alpha})
	this.on('pressmove', function(evt){
		var pos=new cjs.Point(evt.localX-pos0.x,evt.localY-pos0.y)
		beta=-pos.y*0.01+beta0;alpha=pos.x*0.01+alpha0
	});
}

	function signer(date,cou){
			var sign = new createjs.Text('TP '+date, "bold 16px Arial",cou )
			sign.lineWidth=50
			sign.textAlign = "center";
			return sign
	}
	cjs.DisplayObject.prototype.aimante=function(){
		this.x=20*Math.round(this.x/20)
		this.y=20*Math.round(this.y/20)
	};
////////////
////////////Vecteur0 simple
(function() {

function Vecteur0(nom, color,vec) {
	this.Container_constructor();
	this.color = color;
	this.nom = nom;
	this.vec=vec;
	this.setup();
}
var p = createjs.extend(Vecteur0, createjs.Container);

p.setup = function() {
	var fleche=new cjs.Shape()
	this.fleche=fleche
	
	function texteFleche(txt,font,co){
		var f=6
		var cont=new createjs.Container()
		var texte=new createjs.Text(txt,font,co).set({textAlign:'center'})
		var bds=texte.getBounds()
		var lon=bds.width
		var deb=bds.x
		var fl=new createjs.Shape().set({y:-5})
		//this.fl=fl
		fl.graphics.ss(2,"round").s(co).mt(deb,0).lt(deb+lon,0).lt(deb+lon+f*Math.cos(2.6), f*Math.sin(2.6)).mt(deb+lon, 0).lt(deb+lon+f*Math.cos(2.6), -f*Math.sin(2.6))
		cont.addChild(texte,fl)
		return cont
}
	var text = texteFleche(this.nom, "bold 14px Arial", this.color).set({x:this.vec.x+20,y:this.vec.y-5});
	this.text=text
	text.textAlign = "center";
	this.addChild(fleche,text);
	Object.defineProperty(this, "V", {
  get: function() {return new cjs.Point(this.vec.x,this.vec.y)},
  set: function(v) {this.vec=v;text.x=v.x;text.y=v.y-25;if(v.length>0){this.dessineVec()}}
})
	
	this.dessineVec=function(){
		var f=10
		var ang = Math.atan2(this.vec.y,this.vec.x);
		fleche.graphics.clear()
		fleche.graphics.ss(3,"round").s(this.color).mt(0,0).lt(this.vec.x,this. vec.y).lt(this.vec.x+f*Math.cos(ang+2.5), this.vec.y+f*Math.sin(ang+2.5)).mt(this.vec.x,this.vec.y).lt(this.vec.x+f*Math.cos(ang-2.5), this.vec.y+f*Math.sin(ang-2.5));
		stage.update()
	};
	if(this.vec.length>0){
		this.dessineVec()
	}
	
	
} ;

window.Vecteur0 = createjs.promote(Vecteur0, "Container");
}());

/////////////bouton rond

(function() {

function Ressort(long,haut,nb,cou) {
	this.Shape_constructor();
	this.long = long;
	this.haut=haut ;
	this.nb=nb;
	this.cou=cou;
	this.setup();
}
var p = createjs.extend(Ressort, createjs.Shape);

p.setup = function() {
	this.dessine=function(L){
		var h=this.haut,n=this.nb
		var l=L/(this.nb+2)
		this.graphics.clear()
		this.graphics.ss(1).s(this.cou).mt(0,0).qt(l*0.25,-h/2,l,-h/2)
		for(var k=1;k<n+1;k++){
			var deb=k*l
			this.graphics.qt(deb+l*0.85,-h*0.5,deb+l*0.85,h*0).qt(deb+l*0.85,h*0.5,deb+l*0.5,h*0.5).qt(deb+l*0.15,h*0.5,deb+l*0.15,h*0).qt(deb+l*0.15,-h*0.5,deb+l,-h*0.5)
		}
		this.graphics.qt(L-l*0.25,-this.haut/2,L,0)
	}
	this.dessine(this.long)
	Object.defineProperty(this, "lon", {
  get: function() {return this.long},
  set: function(L) {this.dessine(L)}
})
	
} ;

window.Ressort = createjs.promote(Ressort, "Shape");
}());
(function() {

function BoutonRond(label, color1,color2,width) {
	this.Container_constructor();
	this.color1 = color1;
	this.color2=color2;
	this.label = label;
	this.width=width;
	this.setup();
}
var p = createjs.extend(BoutonRond, createjs.Container);


p.setup = function() {
	var text = new createjs.Text(this.label, "bold 16px Arial", "#900")
	this.text=text
	text.textBaseline = "top";
	text.textAlign = "center";
	width=(this.width==undefined?100:this.width)
	
	var height=this.width*0.7;
	
	text.y = -height*0.25;
	var w=text.getMeasuredWidth()+10;
	text.scaleX=w>width?width/w:1;
	
	var background = new createjs.Shape();
	this.background=background;
	//background.graphics.beginFill(this.color).drawRoundRect(0,0,width,height,10);
	background.graphics.rf([this.color1,this.color2], [0, 1], 8, 8, 0, 8, 8, this.width*0.5).de(-this.width*0.5, -height/2, this.width,height);
	this.addChild(background, text);
	this.on("click", this.handleClick);
	this.on("rollover", this.handleRollOver);
	this.on("rollout", this.handleRollOver);
	this.cursor = "pointer";

	this.mouseChildren = false;
	
	//this.offset = Math.random()*10;
//	this.count = 0;
} ;

p.handleClick = function (event) {
	//alert("You clicked on a button: "+this.label);
} ;

p.handleRollOver = function(event) {   
	this.background.scaleX=event.type == "rollover" ? -1 : 1;
	this.background.scaleY=event.type == "rollover" ? -1 : 1;
	stage.update()
};

window.BoutonRond = createjs.promote(BoutonRond, "Container");
}());	
/////////Curseur

(function() {

function Curseur(min,max,lon,valeur,cou) {
	this.Container_constructor();
	
	this.min=min;
	this.max=max;
	this.lon=lon;
	this.valeur=valeur;
	this.cou=cou;
	
	this.coef=this.lon/(this.max-this.min)
	
	this.setup();
}
	var p = createjs.extend(Curseur, createjs.Container);
	p.setup = function() {
	var r=5,cx
	var txt = new createjs.Text('', "bold 14px Arial", this.cou).set({x:0,y:5});
	this.txt=txt
	
	var ligne = new createjs.Shape();
	this.ligne=ligne
	ligne.graphics.beginStroke(this.cou).moveTo(0, 0).lineTo(this.lon, 0);
	
	var circle = new createjs.Shape();
	this.circle=circle
	circle.name='circle'
	circle.x=(this.valeur-this.min)*this.coef;
	circle.graphics.beginRadialGradientFill(["#FFF",this.cou], [0, 1], 3, 2, 0, 0, 0, r).drawCircle(0, 0, r);
	
	this.addChild(ligne, txt, circle);
	this.on("pressmove",function(evt) {
		if(evt.target.name=='circle'){
			cx=evt.localX
			cx=cx<0?0:cx
			cx=cx>this.lon?this.lon:cx
			evt.target.x = cx;
			this.valeur=cx/this.coef+this.min;
		}
		stage.update()
	})
	Object.defineProperty(this, "value", {
  get: function() { return this.circle.x/this.coef+this.min},
  set: function(y) { this.circle.x=this.coef*(y-this.min)}
})
	circle.cursor = "pointer";
	
} ;
window.Curseur = createjs.promote(Curseur, "Container");
}());


///bouton
(function() {

function Button(label, color,width) {
	this.Container_constructor();
	this.color = color;
	this.label = label;
	this.width=width;
	this.setup();
}
var p = createjs.extend(Button, createjs.Container);


p.setup = function() {
	var text = new createjs.Text(this.label, "bold 14px Arial", "#FFF");
	this.text=text
	text.textBaseline = "top";
	text.textAlign = "center";
	width=(this.width==undefined?100:this.width)
	
	var height=20;
	
	text.x = width/2;
	text.y = -height*0.3;
	var w=text.getMeasuredWidth();
	text.scaleX=w>width?width/w:1;
	
	var background = new createjs.Shape();
	this.background=background;
	//background.graphics.beginFill(this.color).drawRoundRect(0,0,width,height,10);
	background.graphics.setStrokeStyle(2).beginStroke(this.color).beginLinearGradientFill(["#FFF",this.color], [0, 0.7], 0, -height*0.7, 0, height*0.5).drawRoundRect(0,-height*0.5,width,height,5);
	this.addChild(background, text); 
	this.on("click", this.handleClick);
	this.on("rollover", this.handleRollOver);
	this.on("rollout", this.handleRollOver);
	this.cursor = "pointer";

	this.mouseChildren = false;

} ;

p.handleClick = function (event) {
	//alert("You clicked on a button: "+this.label);
} ;

p.handleRollOver = function(event) {   
	this.background.scaleY=event.type == "rollover" ? -1 : 1;
	stage.update()
};

window.Bouton = createjs.promote(Button, "Container");
}());

(function() {

function Chrono() {
	this.Container_constructor();
	this.setup();
}
	var p = createjs.extend(Chrono, createjs.Container);
	p.setup = function() {
		var chro=false
		var t=0;this.t=t
		var clic=0;this.clic=clic
		var tc=0;this.tc=tc
		var fond=new cjs.Shape()
		fond.graphics.ss(5).s('#666').f('#999').rr(0,0,90,40,5)
		var contText=new cjs.Container().set({x:20,y:5})
		var txt1=new cjs.Text('00','30px seven_segment','black').set({x:18,textAlign:'right'})
		this.txt1=txt1
		var txt2=new cjs.Text(':','30px seven_segment','black').set({x:20})
		var txt3=new cjs.Text('00','30px seven_segment','black').set({x:30})
		this.txt3=txt3;
		contText.addChild(txt1,txt2,txt3)
		this.addChild(fond,contText)
		
		this.afficheheure=function(){
		//nombre de secondes décimales
			var t1=tc*1;
			//nombre de secondes entières
			var t2=Math.floor(t1);
			//nombre de centisecondes
			var t3=100*(t1-t2);
			var st=t2.toFixed(0);
			var st1=t3.toFixed(0);
			if (st1.length<2) {
				st1="0"+st1;
			}
			this.txt1.text=st;
			this.txt3.text=st1;
		}
	
	this.on('click',function(){
		clic++;
		clic=clic%3;
		switch (clic) {
			case 1 :
				chro=true
				break;
			case 2 :
				chro=false
				break;
			default :
				tc=0;
			}
	})
	this.addEventListener('tick',function(e){
		if(chro){
			//tc++;
//			tc=tc%2500;
			tc+=0.0125
			tc=tc%100
		}
			e.target.afficheheure();
		
		});
	
	this.afficheheure();
	this.cursor='pointer'
} ;
window.Chrono = createjs.promote(Chrono, "Container");
}());