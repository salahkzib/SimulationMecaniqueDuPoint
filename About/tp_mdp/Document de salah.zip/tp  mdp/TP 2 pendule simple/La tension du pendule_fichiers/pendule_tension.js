	var stage
	var cjs=createjs
	var expM1='\u207B\u00B9',ind0='\u2080',pi='\u03c0',om='\u03C9',thet='\u03B8',lamb='\u03BB'
	var joue=true,pend=true,traj=true,forc=false,acc=false,vit=false,souple=true,h = 0.2,t = 0,g = 10,m = 5,l = 150,V,P,Em,OM,V0,tens,tension,ma
	var poids = new cjs.Point(0,m*g);



/////////
	
	function init(){
			var canv = document.getElementById("testCanvas");
	canv.style.backgroundColor='#FFF'
	canv.parentNode.style.backgroundColor=canv.style.backgroundColor;
	//dimensions du canvas
	canv.width=800,canv.height=560;
	//Bouton plein écran
	var btPE=new BoutonPleinEcran(canv,'#009').set({x:50,y:510})

	stage = new createjs.Stage(canv);
	stage.enableMouseOver();
	cjs.Touch.enable(stage)
	cjs.Ticker.framerate=24
	//createjs.Ticker.timingMode = createjs.Ticker.RAF;
	cjs.Ticker.on("tick", tick);
	function tick(evt) { calcule() }
	
	var txtEmploi='- On peut choisir entre "fil souple" et "fil rigide" en cliquant sur le bouton.\n- Deux curseurs permettent de changer ls conditions initiales.\n- Le bouton RAZ permet de réinitialiser l\'animation et le bouton STOP de la "figer".\n- On peut afficher ou cacher les différents vecteurs (forces, vitesse, accélération), et la trajectoire.'
				
	var aide=new Aide(60,60,txtEmploi,400);
	aide.x=30;
	aide.y=30;
	
	var systeme=new cjs.Container().set({x:406,y:233})
	
	
	//boutons
	var contBt=new cjs.Container().set({x:-320,y:220})
	var bt1=new BoutonRond('Stop/Play',"#FFF","#0A0",60).set({x:0,y:0})
	bt1.on('click',function(){joue= !joue})
	var bt2=new BoutonRond('RaZ',"#FFF","#0A0",60).set({x:100,y:0})
	bt2.on('click',function(){raz()})
	var bt3=new Bouton('fil souple','#909',100).set({x:0,y:-220})
	var txtbt3=new cjs.Text('cliquer pour changer','12px Arial','red').set({x:-5,y:-30,visible:false})
	bt3.addChild(txtbt3)
	bt3.on('click',function(){souple=!souple;bt3.text.text=souple?'fil souple':'fil rigide'})
	bt3.on('rollover',function(){txtbt3.visible=true})
	bt3.on('rollout',function(){txtbt3.visible=false})
	contBt.addChild(bt1,bt2,bt3)
	
	//autres boutons
	var contBt1=new cjs.Container().set({x:-70,y:260})
	var bt11=new Bouton('les forces','#909',100).set({x:0,y:0})
	bt11.on('click',function(){forc=!forc})
	var bt12=new Bouton('l\'accélération','#909',100).set({x:110,y:0})
	bt12.on('click',function(){acc = !acc})
	var bt13=new Bouton('la trajectoire','#909',100).set({x:0,y:30})
	bt13.on('click',function(){traj = !traj})
	var bt14=new Bouton('la vitesse','#909',100).set({x:110,y:30})
	bt14.on('click',function(){vit = !vit})
	var txB1=new cjs.Text('Appuyer sur un bouton pour cacher/montrer :','12px Arial','red').set({x:-12,y:-30})
	contBt1.addChild(bt11,bt12,bt13,bt14,txB1)
	

	//pendule
	var contPendule=new cjs.Container()
	
	var support=new cjs.Shape().set({scaleX:0.8,scaleY:0.8})
	support.graphics.lf(["#F00","#FC6","#F00"], [0,0.8,1], -90, 0, 90, 0).mt(-70,230).lt(70,230).lt(90,248).lt(-90,248).lt(-70,230)
	support.graphics.ss(8).ls(["#555","#FFF","#999"], [0,0.8,1], -4, 0, 4, 0).mt(0,-20).lt(0,230)
	support.graphics.ss(1).s('red').f('#F55').dc(0,0,8).s('#888').f('#888').dc(0,0,3)
	var pendule=new cjs.Container().set({y:2,x:0})
	var OP=loc(pendule)
	
	var masse=new cjs.Shape()
	masse.graphics.rf(["#9FF","#039"], [0, 1], 3, 0, 0, 3, 0, 15).drawCircle(0, 0, 8)
	var fil=new cjs.Shape()
	fil.graphics.ss(2).s('#666').mt(0,0).qt(40,40,0,80).qt(-40,120,0,160)
	var trajet=new cjs.Shape()
	pendule.addChild(masse,fil,trajet)
	
	
	contPendule.addChild(support,pendule,trajet)
	
	//curseurs
	var contCur=new cjs.Container().set({x:-320,y:100})
	var curamp=new Curseur(-Math.PI,Math.PI,100,Math.PI/2,'#060').set({y:0})
	curamp.on('pressmove',function(){theta0=curamp.value;curamp.txt.text='angle initial : '+curamp.value.toFixed(2)+' rad'})
	theta0=curamp.value;curamp.txt.text='angle initial : '+curamp.value.toFixed(2)+' rad'
	var curvit=new Curseur(-1,1,100,0.4,'#F00').set({y:40})
	curvit.on('pressmove',function(){v0=curvit.value;curvit.txt.text='vitesse initiale : '+curvit.value.toFixed(2)+' rad.s'+expM1})
	v0=curvit.value;curvit.txt.text='vitesse initiale : '+curvit.value.toFixed(2)+' rad.s'+expM1
	contCur.addChild(curamp,curvit)
	
	//énergie
	var bargraph=new cjs.Container().set({x:250,y:150})
	var Emeca=new cjs.Shape()
	Emeca.graphics.f('#00F').dr(-10,0,20,-100)
	var Epot=new cjs.Shape()
	Epot.graphics.f('#F00').dr(-10,0,20,-100)
	var trait=new cjs.Shape(new cjs.Graphics().s('black').mt(-20,0).lt(20,0))
	var zero=new cjs.Text('0','14px Arial','black').set({x:-35,y:-5})
	var Emtx=new cjs.Text('Em','bold 14px Arial','#00F').set({x:20,y:-40})
	var Eptx=new cjs.Text('Ep','bold 14px Arial','#F00').set({x:20,y:-10})
	var Etx=new cjs.Text('énergies','bold 14px Arial','#90A').set({textAlign:'center',y:10})
	bargraph.addChild(Emeca,Epot,trait,zero,Emtx,Eptx,Etx)
	
	
	//vecteurs
	var contVecteurs=new cjs.Container()
	var Vtension=new Vecteur0('T', 'red',new cjs.Point())
	var Vpoids=new Vecteur0('P', '#090',poids)
	var Vma=new Vecteur0('a', '#909',new cjs.Point())
	var Vvit=new Vecteur0('V', '#00A',new cjs.Point())
	contVecteurs.addChild(Vtension,Vpoids,Vma,Vvit)

	//signature
	var signature=signer('11/2025','#009').set({x:740,y:500})
	
	systeme.addChild(contCur,contBt,contBt1,contPendule,contVecteurs,bargraph)
	
	
	stage.addChild(systeme,signature,aide,btPE)
	
	raz()
		
		
	function calcule(){
		var r
		cjs.Ticker.paused=!joue
		if(joue){
			t += h;
			var mode = pend || !souple;
			switch (mode) {
			case true :
				trajet.graphics.ss(1).s('#F00').mt(OM.x,OM.y);
				RK4();
				OM =new cjs.Point(l*Math.sin(P), l*Math.cos(P));
				r=OM.length
				V0 = new cjs.Point(l*V*Math.cos(P), -l*V*Math.sin(P));
				tens = -m*(g*Math.cos(P)+l*V*V);
				Em = 0.5*m*l*l*V*V+m*g*l*(1-Math.cos(P));
				if (tens>0) {
					pend = false;
				}
				break;
			case false :
				trajet.graphics.ss(1).s('#00F').mt(OM.x,OM.y)
				OM.x += V0.x*h;
				V0.y += g*h;
				OM.y = l+1/m/g*(0.5*m*(V0.x*V0.x+V0.y*V0.y)-Em);
				P = Math.atan2(OM.x, OM.y);
				r = OM.length;
				if (r>l) {
					r=l
					OM.x = l*Math.sin(P);
					OM.y = l*Math.cos(P);
					V = (V0.x*Math.cos(P)-V0.y*Math.sin(P))/r;
					pend = true;
				}
			}
			var H=Math.sqrt(l*l-r*r)/4
			fil.graphics.clear()
			fil.graphics.ss(2).s('#666').mt(0,0).qt(H,r/4,0,r/2).qt(-H,3*r/4,0,r)
			pendule.rotation=-P*180/Math.PI
			masse.y=OM.length
			Ep = m*g*(l-OM.y);
			Emeca.scaleY = 0.0001*Em;
			Emtx.y = -0.01*Em;
			Epot.scaleY = 0.0001*Ep;
			Eptx.y = -0.01*Ep;
//		//vecteurs
			tension = new cjs.Point(tens*Math.sin(P),tens*Math.cos(P));
			//poids = new cjs.Point(0,m*g);
			ma = tension.add(poids)
		if (t<100) {
			trajet.graphics.lineTo(OM.x, OM.y);
		}
		trajet.visible = traj;
		contVecteurs.pos(OM.add(OP))
		Vtension.V=tension
		Vma.V=ma
		Vvit.V=V0
		Vpoids.visible=forc
		Vtension.visible=(mode&&forc)
		Vma.visible=acc
		Vvit.visible=vit
		
		
		stage.update()
		}
				
	
	}
	function initGraph(){

	}
	function raz(){
	t=0
	V = curvit.value;
	P = curamp.value;
	OM =new cjs.Point(l*Math.sin(P), l*Math.cos(P));
	Em = 0.5*m*l*l*V*V-m*g*l*Math.cos(P);
	pend = true;
	joue = true;
	trajet.graphics.clear();
	trajet.graphics.ss(1).s('red').mt(l*Math.sin(P), l*Math.cos(P));
		stage.update()

	}
	function A (Pos, Vit) {
		return (-g/l*Math.sin(Pos));
};
	function RK4(){
		var k1 = h*V;
		var j1 = h*A(P, V);
		// 
		var k2 = h*(V+j1/2);
		var j2 = h*A(P+k1/2, V);
		//
		var k3 = h*(V+j2/2);
		var j3 = h*A(P+k2/2, V);
		//
		var k4 = h*(V+j3);
		var j4 = h*A(P+k3, V);
		//
		var K = (k1+2*k2+2*k3+k4)/6;
		P += K;
		var J = (j1+2*j2+2*j3+j4)/6;
		V += J;
	}

}
/////////////fonctions


cjs.DisplayObject.prototype.pos = function(P) {
	this.x = P.x;
	this.y = P.y;
};

function loc(ob){return new cjs.Point(ob.x,ob.y)}
cjs.DisplayObject.prototype.tourne=function(){
	var pos0
	this.on('mousedown',function(evt){pos0=new cjs.Point(evt.localX,evt.localY),beta0=beta,alpha0=alpha})
	this.on('pressmove', function(evt){
		var pos=new cjs.Point(evt.localX-pos0.x,evt.localY-pos0.y)
		beta=-pos.y*0.01+beta0;alpha=pos.x*0.01+alpha0
	});
}

	function signer(date,cou){
			var sign = new createjs.Text('TP '+date, "bold 16px Arial",cou )
			sign.lineWidth=50
			sign.textAlign = "center";
			return sign
	}
	cjs.DisplayObject.prototype.aimante=function(){
		this.x=20*Math.round(this.x/20)
		this.y=20*Math.round(this.y/20)
	};
////////////
////////////Vecteur0 simple
(function() {

function Vecteur0(nom, color,vec) {
	this.Container_constructor();
	this.color = color;
	this.nom = nom;
	this.vec=vec;
	this.setup();
}
var p = createjs.extend(Vecteur0, createjs.Container);

p.setup = function() {
	var fleche=new cjs.Shape()
	this.fleche=fleche
	
	function texteFleche(txt,font,co){
		var f=6
		var cont=new createjs.Container()
		var texte=new createjs.Text(txt,font,co).set({textAlign:'center'})
		var bds=texte.getBounds()
		var lon=bds.width
		var deb=bds.x
		var fl=new createjs.Shape().set({y:-5})
		//this.fl=fl
		fl.graphics.ss(2).s(co).mt(deb,0).lt(deb+lon,0).lt(deb+lon+f*Math.cos(2.6), f*Math.sin(2.6)).mt(deb+lon, 0).lt(deb+lon+f*Math.cos(2.6), -f*Math.sin(2.6))
		cont.addChild(texte,fl)
		return cont
}
	var text = texteFleche(this.nom, "bold 14px Arial", this.color).set({x:this.vec.x+10,y:this.vec.y-25});
	this.text=text
	text.textAlign = "center";
	this.addChild(fleche,text);
	Object.defineProperty(this, "V", {
  get: function() {return new cjs.Point(this.vec.x,this.vec.y)},
  set: function(v) {this.vec=v;text.x=v.x;text.y=v.y-25;if(v.length>0){this.dessineVec()}}
})
	
	this.dessineVec=function(){
		var f=8
		var ang = Math.atan2(this.vec.y,this.vec.x);
		fleche.graphics.clear()
		fleche.graphics.ss(2).s(this.color).mt(0,0).lt(this.vec.x,this. vec.y).lt(this.vec.x+f*Math.cos(ang+2.5), this.vec.y+f*Math.sin(ang+2.5)).mt(this.vec.x,this.vec.y).lt(this.vec.x+f*Math.cos(ang-2.5), this.vec.y+f*Math.sin(ang-2.5));
		stage.update()
	};
	if(this.vec.length>0){
		this.dessineVec()
	}
	
	
} ;

window.Vecteur0 = createjs.promote(Vecteur0, "Container");
}());

/////////////bouton rond
(function() {

function BoutonRond(label, color1,color2,width) {
	this.Container_constructor();
	this.color1 = color1;
	this.color2=color2;
	this.label = label;
	this.width=width;
	this.setup();
}
var p = createjs.extend(BoutonRond, createjs.Container);


p.setup = function() {
	var text = new createjs.Text(this.label, "bold 16px Arial", "#060")
	this.text=text
	text.textBaseline = "top";
	text.textAlign = "center";
	width=(this.width==undefined?100:this.width)
	
	var height=this.width*0.7;
	
	text.y = -height*0.25;
	var w=text.getMeasuredWidth()+10;
	text.scaleX=w>width?width/w:1;
	
	var background = new createjs.Shape();
	this.background=background;
	//background.graphics.beginFill(this.color).drawRoundRect(0,0,width,height,10);
	background.graphics.rf([this.color1,this.color2], [0, 1], 8, 8, 0, 8, 8, this.width*0.5).de(-this.width*0.5, -height/2, this.width,height);
	this.addChild(background, text);
	this.on("click", this.handleClick);
	this.on("rollover", this.handleRollOver);
	this.on("rollout", this.handleRollOver);
	this.cursor = "pointer";

	this.mouseChildren = false;
	
	//this.offset = Math.random()*10;
//	this.count = 0;
} ;

p.handleClick = function (event) {
	//alert("You clicked on a button: "+this.label);
} ;

p.handleRollOver = function(event) {   
	this.background.scaleX=event.type == "rollover" ? -1 : 1;
	this.background.scaleY=event.type == "rollover" ? -1 : 1;
	stage.update()
};

window.BoutonRond = createjs.promote(BoutonRond, "Container");
}());	
/////////Curseur

(function() {

function Curseur(min,max,lon,valeur,cou) {
	this.Container_constructor();
	
	this.min=min;
	this.max=max;
	this.lon=lon;
	this.valeur=valeur;
	this.cou=cou;
	
	this.coef=this.lon/(this.max-this.min)
	
	this.setup();
}
	var p = createjs.extend(Curseur, createjs.Container);
	p.setup = function() {
	var r=5,cx
	var txt = new createjs.Text('', "bold 13px Arial", this.cou).set({x:this.lon/2,y:10,textAlign:'center'});
	this.txt=txt
	
	var ligne = new createjs.Shape();
	this.ligne=ligne
	ligne.graphics.beginStroke(this.cou).moveTo(0, 0).lineTo(this.lon, 0);
	
	var circle = new createjs.Shape();
	this.circle=circle
	circle.name='circle'
	circle.x=(this.valeur-this.min)*this.coef;
	circle.graphics.beginRadialGradientFill(["#FFF",this.cou], [0, 1], 3, 2, 0, 0, 0, r).drawCircle(0, 0, r);
	
	this.addChild(ligne, txt, circle);
	this.on("pressmove",function(evt) {
		if(evt.target.name=='circle'){
			cx=evt.localX
			cx=cx<0?0:cx
			cx=cx>this.lon?this.lon:cx
			evt.target.x = cx;
			this.valeur=cx/this.coef+this.min;
		}
		stage.update()
	})
	Object.defineProperty(this, "value", {
  get: function() { return this.circle.x/this.coef+this.min},
  set: function(y) { this.circle.x=this.coef*(y-this.min)}
})
	circle.cursor = "pointer";
	
} ;
window.Curseur = createjs.promote(Curseur, "Container");
}());


///bouton
(function() {

function Button(label, color,width) {
	this.Container_constructor();
	this.color = color;
	this.label = label;
	this.width=width;
	this.setup();
}
var p = createjs.extend(Button, createjs.Container);


p.setup = function() {
	var text = new createjs.Text(this.label, "bold 14px Arial", "#FFF");
	this.text=text
	text.textBaseline = "top";
	text.textAlign = "center";
	width=(this.width==undefined?100:this.width)
	
	var height=20;
	
	text.x = width/2;
	text.y = -height*0.3;
	var w=text.getMeasuredWidth();
	text.scaleX=w>width?width/w:1;
	
	var background = new createjs.Shape();
	this.background=background;
	//background.graphics.beginFill(this.color).drawRoundRect(0,0,width,height,10);
	background.graphics.setStrokeStyle(2).beginStroke(this.color).beginLinearGradientFill(["#FFF",this.color], [0, 0.7], 0, -height*0.7, 0, height*0.5).drawRoundRect(0,-height*0.5,width,height,5);
	this.addChild(background, text); 
	this.on("click", this.handleClick);
	this.on("rollover", this.handleRollOver);
	this.on("rollout", this.handleRollOver);
	this.cursor = "pointer";

	this.mouseChildren = false;

} ;

p.handleClick = function (event) {
	//alert("You clicked on a button: "+this.label);
} ;

p.handleRollOver = function(event) {   
	this.background.scaleY=event.type == "rollover" ? -1 : 1;
	stage.update()
};

window.Bouton = createjs.promote(Button, "Container");
}());